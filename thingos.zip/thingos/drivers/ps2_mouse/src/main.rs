//! PS/2 Mouse Driver (IRQ-assisted)
//!
//! Subscribes to IRQ12 via IOAPIC and drains pending PS/2 bytes when the IRQ
//! fires. The wait is deliberately time-bounded so the mouse still works when
//! virtual hardware or interrupt routing fails to deliver IRQ12.
#![no_std]
#![no_main]
use core::default::Default;
use core::sync::atomic::{AtomicU64, Ordering};

use abi::driver_interface::{
    DRIVER_DESCRIPTOR_ABI_VERSION, DeviceInfo, DriverClass, DriverDescriptor, DriverEntryCtx,
    ProbeResult, Status,
};
use abi::trace::input_source;
use stem::abi::module_manifest::{MANIFEST_MAGIC, ManifestHeader, ModuleKind, device_kind_bytes};
use stem::syscall::message::msg_send;
use stem::syscall::vfs::{vfs_close, vfs_open, vfs_read};
use stem::syscall::{ioport_read, ioport_write, irq_subscribe, trace_mark_input};
use stem::time::Duration;
use stem::wait_set::WaitSet;
use stem::{debug, error, info, trace, warn};

const THINGOS_DRIVER_NAME: &[u8] = b"ps2_mouse";

#[cfg(target_arch = "x86_64")]
unsafe extern "C" {
    fn thingos_driver_start_safe(ctx: *const DriverEntryCtx) -> Status;
}

#[unsafe(no_mangle)]
#[used]
pub static THINGOS_DRIVER: DriverDescriptor = DriverDescriptor {
    abi_version: DRIVER_DESCRIPTOR_ABI_VERSION,
    driver_name_ptr: THINGOS_DRIVER_NAME.as_ptr(),
    driver_name_len: THINGOS_DRIVER_NAME.len(),
    driver_class: DriverClass::Input,
    flags: 0,
    probe: thingos_driver_probe,
    #[cfg(target_arch = "x86_64")]
    start: thingos_driver_start_safe,
    #[cfg(not(target_arch = "x86_64"))]
    start: thingos_driver_start,
};

#[cfg(target_arch = "x86_64")]
core::arch::global_asm!(
    r#"
    .section .text
    .global thingos_driver_start_safe
    thingos_driver_start_safe:
        // RSP = 16n (kernel spawn)
        sub rsp, 8
        // Store RDI (boot_fd) and align stack to 16n + 8 for SysV.
        push rdi
        // Call std initialization (TLS, etc)
        call thingos_runtime_setup
        // Restore RDI and realign for the next call.
        pop rdi
        add rsp, 8
        // CALL will push 8 bytes, so inside Rust entry RSP = 16n + 8.
        call thingos_driver_start_rust
        ret
"#
);

#[unsafe(no_mangle)]
unsafe extern "C" fn thingos_driver_start_rust(ctx: *const DriverEntryCtx) -> Status {
    thingos_driver_start(ctx)
}

unsafe extern "C" fn thingos_driver_probe(
    _dev: *const DeviceInfo,
    out: *mut ProbeResult,
) -> Status {
    if out.is_null() {
        return Status::InvalidArgument;
    }
    let out = &mut *out;
    out.matched = 0;
    out.score = 0;
    out.claimed_class = DriverClass::Input;
    out.flags = 0;
    Status::NoMatch
}

unsafe extern "C" fn thingos_driver_start(_ctx: *const DriverEntryCtx) -> Status {
    main(0)
}

#[unsafe(link_section = ".thing_manifest")]
#[unsafe(no_mangle)]
#[used]
pub static MANIFEST: ManifestHeader = ManifestHeader {
    magic: MANIFEST_MAGIC,
    kind: ModuleKind::Driver,
    device_kind: device_kind_bytes(b"drv.Ps2Mouse"),
    version: 1,
    _reserved: 0,
};

const PS2_DATA: usize = 0x60;
const PS2_STATUS: usize = 0x64;
const PS2_CMD: usize = 0x64;

const STATUS_OUTPUT_FULL: usize = 0x01;
const STATUS_INPUT_FULL: usize = 0x02;
const STATUS_AUX_DATA: usize = 0x20;

const CMD_ENABLE_AUX: u8 = 0xA8;
const CMD_READ_CFG: u8 = 0x20;
const CMD_WRITE_CFG: u8 = 0x60;
const CMD_WRITE_AUX: u8 = 0xD4;
const MOUSE_ENABLE: u8 = 0xF4;

/// IRQ12 vector (mouse) - legacy IRQ12 maps to vector 0x2C after IOAPIC remap
const MOUSE_VECTOR: u8 = 0x2C;
const POLLING_INTERVAL_MS: u64 = 8;
const IRQ_ASSIST_POLL_MS: u64 = 4;
const INPUT_TRACE_INITIAL: u64 = 24;
const INPUT_TRACE_INTERVAL: u64 = 128;
const POINTER_MOTION_MIN_INTERVAL_NS: u64 = 16_666_666;
const POINTER_MOTION_MAX_DELTA_PER_EVENT: i32 = 20;
const POINTER_MOTION_MAX_PENDING_DELTA: i32 = 40;

static PS2_MOUSE_BYTE_COUNT: AtomicU64 = AtomicU64::new(0);
static PS2_MOUSE_DRAIN_COUNT: AtomicU64 = AtomicU64::new(0);

/// Preferred PS/2 mouse sample rate (Hz). Keep this modest while isolating
/// compositor freezes under fast pointer movement.
const PREFERRED_SAMPLE_RATE: u8 = 60;
/// Fallback sample rate used when the device rejects `PREFERRED_SAMPLE_RATE`.
const FALLBACK_SAMPLE_RATE: u8 = 40;

fn wait_input_empty() {
    // Serialization note: this function must be called before every command or
    // data byte written to PS2_CMD / PS2_DATA.  It ensures the controller's
    // input buffer is clear.  All PS/2 I/O (init, IRQ, and polling paths) must
    // call this before writing so command/data bytes do not interleave.
    for _ in 0..10_000 {
        if ioport_read(PS2_STATUS, 1) & STATUS_INPUT_FULL == 0 {
            return;
        }
        stem::yield_now();
    }
    // Timed out: log the controller status so the phase and cause are auditable.
    let status = ioport_read(PS2_STATUS, 1) as u8;
    warn!("wait_input_empty timed out: status=0x{:02x}; proceeding anyway", status);
}

fn flush_output_buffer() {
    // Drain up to 16 bytes of garbage
    for _ in 0..16 {
        let status = ioport_read(PS2_STATUS, 1);
        if status & STATUS_OUTPUT_FULL != 0 {
            if status & STATUS_AUX_DATA != 0 {
                let b = ioport_read(PS2_DATA, 1);
                trace!("Flushed PS/2 mouse garbage byte: 0x{:02x}", b);
            } else {
                // Not ours, leave it for ps2_kbd
                break;
            }
        } else {
            break;
        }
        stem::yield_now();
    }
}

fn read_data_filtered(expect_aux: bool, label: &str) -> Option<u8> {
    let mut discarded_aux: u32 = 0;
    let mut discarded_non_aux: u32 = 0;
    for _ in 0..20_000 {
        let status = ioport_read(PS2_STATUS, 1);
        if status & STATUS_OUTPUT_FULL == 0 {
            stem::yield_now();
            continue;
        }
        let is_aux = (status & STATUS_AUX_DATA) != 0;

        if is_aux != expect_aux {
            // Count mismatched bytes.  Do not consume them; yield so the
            // appropriate driver (ps2_kbd or ps2_mouse) gets a chance to run
            // and drain the byte from the FIFO.
            if is_aux {
                discarded_aux += 1;
            } else {
                discarded_non_aux += 1;
            }
            stem::yield_now();
            continue;
        }
        let byte = ioport_read(PS2_DATA, 1) as u8;
        return Some(byte);
    }
    let status = ioport_read(PS2_STATUS, 1) as u8;
    debug!(
        "Timed out waiting for {}: status=0x{:02x} discarded_aux={} discarded_non_aux={}",
        label, status, discarded_aux, discarded_non_aux
    );
    None
}

fn read_controller_config() -> u8 {
    wait_input_empty();
    // Flush any pending data (e.g. key scancodes) before asking for config
    flush_output_buffer();
    ioport_write(PS2_CMD, CMD_READ_CFG as usize, 1);
    if let Some(val) = read_data_filtered(false, "controller cfg") {
        return val;
    }
    // Fallback if we keep getting garbage
    debug!("read_cfg failed; assuming default safe PS/2 mouse config 0x47");
    0x47 // IRQ1, IRQ12, SysFlag, Translation
}

fn write_controller_config(cfg: u8) {
    wait_input_empty();
    ioport_write(PS2_CMD, CMD_WRITE_CFG as usize, 1);
    wait_input_empty();
    ioport_write(PS2_DATA, cfg as usize, 1);
}

fn send_aux_byte(byte: u8) {
    wait_input_empty();
    ioport_write(PS2_CMD, CMD_WRITE_AUX as usize, 1);
    wait_input_empty();
    ioport_write(PS2_DATA, byte as usize, 1);
}

/// Send the Set Sample Rate command (0xF3) followed by `rate`.
///
/// Returns `true` if the device acknowledged both bytes with 0xFA, `false`
/// otherwise. Callers should fall back to a lower rate on failure.
fn set_sample_rate(rate: u8) -> bool {
    send_aux_byte(0xF3);
    let cmd_ack = read_data_filtered(true, "sample rate cmd ACK").unwrap_or(0);
    if cmd_ack != 0xFA {
        debug!("Sample rate command NACK: ack=0x{:02x} rate={}", cmd_ack, rate);
        return false;
    }
    send_aux_byte(rate);
    let rate_ack = read_data_filtered(true, "sample rate set ACK").unwrap_or(0);
    if rate_ack != 0xFA {
        debug!("Sample rate set NACK: ack=0x{:02x} rate={}", rate_ack, rate);
        return false;
    }
    true
}

fn init_mouse() {
    info!("Initializing PS/2 mouse controller...");
    trace!("ps2.phase=aux_enable_begin");

    // Clear any initial garbage
    flush_output_buffer();

    // Enable aux port
    wait_input_empty();
    ioport_write(PS2_CMD, CMD_ENABLE_AUX as usize, 1);
    for _ in 0..10 {
        stem::yield_now();
    }

    // Ensure IRQ12 is enabled (Bit 1) and Mouse Disabled (Bit 5) is CLEARED.
    // Bit 5: 1 = Mouse Disabled, 0 = Mouse Enabled.
    let cfg = read_controller_config();

    // Force: Set Bit 1 (IRQ12), Clear Bit 5 (Mouse Disable)
    let new_cfg = (cfg | 0x02) & !0x20;

    let cfg_changed = new_cfg != cfg;
    if cfg_changed {
        write_controller_config(new_cfg);
    }

    trace!("ps2.phase=aux_enable_done");

    // Reset mouse (0xFF)
    trace!("ps2.phase=mouse_reset_begin");
    send_aux_byte(0xFF);
    let ack = read_data_filtered(true, "reset ACK (0xfa)").unwrap_or(0);
    let mut bat = 0;
    let mut id = 1;
    if ack == 0xFA {
        bat = read_data_filtered(true, "BAT byte (0xAA)").unwrap_or(0);
        id = read_data_filtered(true, "Device ID (0x00)").unwrap_or(1);
    }
    trace!("ps2.phase=mouse_reset_done");

    trace!("ps2.phase=mouse_sample_rate_begin");
    let sample_rate = if set_sample_rate(PREFERRED_SAMPLE_RATE) {
        PREFERRED_SAMPLE_RATE
    } else {
        if set_sample_rate(FALLBACK_SAMPLE_RATE) {
            FALLBACK_SAMPLE_RATE
        } else {
            warn!(
                "PS/2 mouse fallback sample rate {} Hz failed; continuing with the device default",
                FALLBACK_SAMPLE_RATE
            );
            0
        }
    };
    trace!("ps2.phase=mouse_sample_rate_done");

    send_aux_byte(0xE8);
    read_data_filtered(true, "resolution ACK");
    send_aux_byte(3);
    read_data_filtered(true, "resolution set ACK");

    send_aux_byte(0xE9);
    let _s_ack = read_data_filtered(true, "status request ACK");
    let b1 = read_data_filtered(true, "status byte 1").unwrap_or(0);
    let b2 = read_data_filtered(true, "status byte 2").unwrap_or(0);
    let b3 = read_data_filtered(true, "status byte 3").unwrap_or(0);

    trace!("ps2.phase=irq_enable_begin");
    // Bit 5 indicates Enable/Disable status (1 = Enabled, 0 = Disabled).
    // If it is 0, data reporting is disabled, so we must enable it.
    let enable_ack = if b1 & 0x20 == 0 {
        // Enable mouse data reporting (0xF4)
        send_aux_byte(MOUSE_ENABLE);
        Some(read_data_filtered(true, "enable ACK (0xFA)").unwrap_or(0))
    } else {
        None
    };
    trace!("ps2.phase=irq_enable_done");

    stem::sleep_ms(100);

    // Drain any lingering response bytes.
    let mut drained = 0u32;
    let mut last_drained = 0u8;
    for _ in 0..10 {
        if ioport_read(PS2_STATUS, 1) & STATUS_OUTPUT_FULL != 0 {
            let byte = ioport_read(PS2_DATA, 1) as u8;
            drained += 1;
            last_drained = byte;
            trace!("Drained lingering PS/2 mouse byte 0x{:02x}", byte);
        }
        stem::sleep_ms(10);
    }

    debug!(
        "PS/2 mouse init summary: cfg=0x{:02x}->0x{:02x} changed={} reset_ack=0x{:02x} bat=0x{:02x} id=0x{:02x} sample_rate={} status=[0x{:02x},0x{:02x},0x{:02x}] enable_ack={} drained={} last_drained=0x{:02x}",
        cfg,
        new_cfg,
        cfg_changed,
        ack,
        bat,
        id,
        sample_rate,
        b1,
        b2,
        b3,
        enable_ack.unwrap_or(0),
        drained,
        last_drained
    );
    info!("PS/2 mouse controller ready");
}

/// Path where bristle publishes its inbox-owning PID.
const BRISTLE_PID_PATH: &str = "/run/bristle/pid";

fn read_u32_file(path: &str) -> Option<u32> {
    let fd = vfs_open(path, abi::syscall::vfs_flags::O_RDONLY).ok()?;
    let mut buf = [0u8; 32];
    let n = vfs_read(fd, &mut buf).unwrap_or(0);
    let _ = vfs_close(fd);
    if n == 0 {
        return None;
    }
    let s = core::str::from_utf8(&buf[..n]).ok()?.trim();
    s.parse::<u32>().ok()
}

#[stem::main]
fn main(_raw_arg: usize) -> ! {
    stem::debug!("PS/2 mouse service online; waiting for bristle pid");

    if let Err(e) = stem::fs::wait_until_exists(BRISTLE_PID_PATH) {
        stem::error!("Failed waiting for {}: {:?}", BRISTLE_PID_PATH, e);
        loop {
            stem::time::sleep_ms(1000);
        }
    }

    let bristle_pid = match read_u32_file(BRISTLE_PID_PATH) {
        Some(pid) if pid != 0 => pid,
        _ => {
            stem::error!("Failed to read bristle pid from {}", BRISTLE_PID_PATH);
            loop {
                stem::time::sleep_ms(1000);
            }
        }
    };

    stem::debug!("Connected PS/2 mouse events to bristle pid={}.", bristle_pid);

    init_mouse();

    // Subscribe to mouse interrupt
    match irq_subscribe(MOUSE_VECTOR) {
        Ok(()) => {
            debug!("Subscribed to PS/2 mouse IRQ12: vector=0x{:02x}", MOUSE_VECTOR);
            interrupt_loop(bristle_pid);
        }
        Err(e) => {
            debug!("PS/2 mouse IRQ subscribe failed ({:?}); falling back to polling", e);
            polling_loop(bristle_pid);
        }
    }
}

mod mouse;

use abi::hid::{
    BRISTLE_EVENT_MAGIC, BRISTLE_EVENT_VERSION, BristleEventHeader, EventType,
    KIND_BRISTLE_DEVICE_EVENT, PointerButtonPayload, PointerMovePayload,
};
use mouse::{MouseState, PointerEvent};

#[derive(Default)]
struct MotionCoalescer {
    pending_dx: i32,
    pending_dy: i32,
    last_sent_ns: u64,
}

impl MotionCoalescer {
    fn add(&mut self, dx: i16, dy: i16) {
        self.pending_dx = self
            .pending_dx
            .saturating_add(dx as i32)
            .clamp(-POINTER_MOTION_MAX_PENDING_DELTA, POINTER_MOTION_MAX_PENDING_DELTA);
        self.pending_dy = self
            .pending_dy
            .saturating_add(dy as i32)
            .clamp(-POINTER_MOTION_MAX_PENDING_DELTA, POINTER_MOTION_MAX_PENDING_DELTA);
    }

    fn has_pending(&self) -> bool {
        self.pending_dx != 0 || self.pending_dy != 0
    }

    fn due(&self, now_ns: u64) -> bool {
        self.has_pending()
            && (self.last_sent_ns == 0
                || now_ns.saturating_sub(self.last_sent_ns) >= POINTER_MOTION_MIN_INTERVAL_NS)
    }

    fn take(&mut self, now_ns: u64) -> (i16, i16) {
        let dx = clamp_i16(
            self.pending_dx
                .clamp(-POINTER_MOTION_MAX_DELTA_PER_EVENT, POINTER_MOTION_MAX_DELTA_PER_EVENT),
        );
        let dy = clamp_i16(
            self.pending_dy
                .clamp(-POINTER_MOTION_MAX_DELTA_PER_EVENT, POINTER_MOTION_MAX_DELTA_PER_EVENT),
        );
        self.pending_dx = 0;
        self.pending_dy = 0;
        self.last_sent_ns = now_ns;
        (dx, dy)
    }
}

fn clamp_i16(value: i32) -> i16 {
    value.clamp(i16::MIN as i32, i16::MAX as i32) as i16
}

fn send_pointer_event(bristle_pid: u32, event_type: EventType, payload: &[u8]) -> bool {
    let timestamp_ns = stem::monotonic_ns();
    let mut buf = [0u8; 24];
    let header = BristleEventHeader {
        magic: BRISTLE_EVENT_MAGIC,
        version: BRISTLE_EVENT_VERSION,
        event_type: event_type as u16,
        timestamp_ns,
        payload_len: payload.len() as u32,
    };
    let len = BristleEventHeader::SIZE + payload.len();
    buf[..BristleEventHeader::SIZE].copy_from_slice(&header.to_bytes());
    buf[BristleEventHeader::SIZE..len].copy_from_slice(payload);

    msg_send(bristle_pid, abi::KindId(KIND_BRISTLE_DEVICE_EVENT), &buf[..len]).is_ok()
}

fn record_drop(drop_counter: &mut u32, bristle_pid: u32) {
    *drop_counter = drop_counter.wrapping_add(1);
    if *drop_counter <= 4 || *drop_counter % 100 == 0 {
        trace!("Dropped {} mouse events: send to pid={} failed", *drop_counter, bristle_pid);
    }
}

fn flush_motion_if_due(bristle_pid: u32, motion: &mut MotionCoalescer, drop_counter: &mut u32) {
    let now_ns = stem::monotonic_ns();
    if !motion.due(now_ns) {
        return;
    }
    flush_one_motion(bristle_pid, motion, drop_counter, now_ns);
}

fn flush_motion_now(bristle_pid: u32, motion: &mut MotionCoalescer, drop_counter: &mut u32) {
    if motion.has_pending() {
        flush_one_motion(bristle_pid, motion, drop_counter, stem::monotonic_ns());
    }
}

fn flush_one_motion(
    bristle_pid: u32,
    motion: &mut MotionCoalescer,
    drop_counter: &mut u32,
    now_ns: u64,
) {
    let (dx, dy) = motion.take(now_ns);
    if dx == 0 && dy == 0 {
        return;
    }

    let payload = PointerMovePayload { dx, dy };
    if !send_pointer_event(bristle_pid, EventType::PointerMove, &payload.to_bytes()) {
        record_drop(drop_counter, bristle_pid);
    }
}

fn send_mouse_events(
    bristle_pid: u32,
    state: &mut MouseState,
    motion: &mut MotionCoalescer,
    packet: &[u8; 3],
    drop_counter: &mut u32,
) {
    let (events, count) = state.process_packet(packet);
    for i in 0..count {
        if let Some(evt) = events[i] {
            match evt {
                PointerEvent::Move { dx, dy } => {
                    motion.add(dx, dy);
                    flush_motion_if_due(bristle_pid, motion, drop_counter);
                }
                PointerEvent::ButtonDown { button } => {
                    flush_motion_now(bristle_pid, motion, drop_counter);
                    let payload = PointerButtonPayload { button, _pad: 0 };
                    if !send_pointer_event(
                        bristle_pid,
                        EventType::PointerButtonDown,
                        &payload.to_bytes(),
                    ) {
                        record_drop(drop_counter, bristle_pid);
                    }
                }
                PointerEvent::ButtonUp { button } => {
                    flush_motion_now(bristle_pid, motion, drop_counter);
                    let payload = PointerButtonPayload { button, _pad: 0 };
                    if !send_pointer_event(
                        bristle_pid,
                        EventType::PointerButtonUp,
                        &payload.to_bytes(),
                    ) {
                        record_drop(drop_counter, bristle_pid);
                    }
                }
            }
        }
    }
}

/// Drain all pending mouse data and assemble packets.
///
/// Returns the number of raw bytes consumed from the PS/2 FIFO.
fn drain_mouse_data(
    bristle_pid: u32,
    state: &mut MouseState,
    motion: &mut MotionCoalescer,
    packet: &mut [u8; 3],
    idx: &mut usize,
    drop_counter: &mut u32,
) -> usize {
    let start_ns = stem::monotonic_ns();
    let mut bytes_read = 0usize;
    let mut packets_sent = 0usize;
    for _ in 0..16 {
        let status = ioport_read(PS2_STATUS, 1);

        if status & STATUS_OUTPUT_FULL == 0 {
            break;
        }

        if status & STATUS_AUX_DATA != 0 {
            let byte = ioport_read(PS2_DATA, 1) as u8;
            bytes_read += 1;
            let byte_no = PS2_MOUSE_BYTE_COUNT.fetch_add(1, Ordering::Relaxed) + 1;
            if should_log_input(byte_no) {
                trace!(
                    "PS/2 mouse take_scancode: byte=0x{:02x} status=0x{:02x} packet_idx={} drain_depth={}",
                    byte, status, *idx, bytes_read
                );
            }

            // First byte must have bit 3 set and overflow bits clear.
            if *idx == 0 && !mouse::is_packet_start(byte) {
                continue;
            }

            packet[*idx] = byte;
            *idx += 1;

            if *idx == 3 {
                if mouse::packet_plausible(packet) {
                    send_mouse_events(bristle_pid, state, motion, packet, drop_counter);
                    packets_sent += 1;
                    *idx = 0;
                } else if mouse::is_packet_start(packet[1]) {
                    packet[0] = packet[1];
                    packet[1] = packet[2];
                    *idx = 2;
                } else if mouse::is_packet_start(packet[2]) {
                    packet[0] = packet[2];
                    *idx = 1;
                } else {
                    *idx = 0;
                }
            }
        } else {
            // Shared i8042 controller: leave keyboard bytes for ps2_kbd.
            // Consuming them here makes keyboard input appear dead.
            break;
        }
    }
    if bytes_read != 0 {
        let elapsed_ns = stem::monotonic_ns().saturating_sub(start_ns);
        let drain_no = PS2_MOUSE_DRAIN_COUNT.fetch_add(1, Ordering::Relaxed) + 1;
        if should_log_input(drain_no) {
            trace!(
                "PS/2 mouse drain exit: bytes={} packets={} pending_idx={} elapsed_ns={} dropped={}",
                bytes_read, packets_sent, *idx, elapsed_ns, *drop_counter
            );
        }
    }
    bytes_read
}

/// IRQ-assisted service loop (primary path).
///
/// Waits briefly for IRQ12, then drains all pending PS/2 bytes even if the wait
/// timed out. This keeps normal interrupt latency low without making pointer
/// updates depend on a perfectly routed IRQ line.
fn interrupt_loop(bristle_pid: u32) -> ! {
    debug!(
        "Using PS/2 mouse IRQ-assisted loop: vector=0x{:02x} poll={}ms",
        MOUSE_VECTOR, IRQ_ASSIST_POLL_MS
    );

    let mut waitset = WaitSet::new();
    let irq_token = match waitset.add_irq(MOUSE_VECTOR as u64) {
        Ok(token) => token,
        Err(e) => {
            warn!("Failed to add PS/2 mouse IRQ wait source ({:?}); switching to polling", e);
            polling_loop(bristle_pid);
        }
    };

    let mut packet = [0u8; 3];
    let mut idx = 0usize;
    let mut mouse_state = MouseState::new();
    let mut motion = MotionCoalescer::default();
    let mut drop_counter = 0u32;
    let mut irq_wake_count = 0u64;
    let mut timeout_count = 0u64;
    let mut input_count = 0u64;
    let mut rate_window_start_ns = stem::monotonic_ns();
    let mut rate_window_input = 0u64;

    loop {
        if should_log_input(irq_wake_count + timeout_count + 1) {
            trace!(
                "ps2_mouse IRQ wait: vector=0x{:02x} wakes={} timeouts={} input_total={} dropped={}.",
                MOUSE_VECTOR, irq_wake_count, timeout_count, input_count, drop_counter
            );
        }
        match waitset.wait(Some(Duration::from_millis(IRQ_ASSIST_POLL_MS))) {
            Ok(events) => {
                let mut saw_irq = false;
                for event in events {
                    if event.token() == irq_token && event.is_irq() {
                        irq_wake_count = irq_wake_count.wrapping_add(1);
                        saw_irq = true;
                    }
                }
                if !saw_irq {
                    timeout_count = timeout_count.wrapping_add(1);
                }
                if saw_irq && should_log_input(irq_wake_count) {
                    trace!(
                        "PS/2 mouse irq_wait exit: vector=0x{:02x} wakes={} timeouts={}",
                        MOUSE_VECTOR, irq_wake_count, timeout_count
                    );
                }
            }
            Err(e) => {
                warn!(
                    "PS/2 mouse IRQ wait error ({:?}) after {} wakes; switching to polling fallback",
                    e, irq_wake_count
                );
                break;
            }
        }

        let drained = drain_mouse_data(
            bristle_pid,
            &mut mouse_state,
            &mut motion,
            &mut packet,
            &mut idx,
            &mut drop_counter,
        );
        flush_motion_if_due(bristle_pid, &mut motion, &mut drop_counter);
        input_count = input_count.wrapping_add(drained as u64);
        rate_window_input = rate_window_input.wrapping_add(drained as u64);
        let now_ns = stem::monotonic_ns();
        let window_ns = now_ns.saturating_sub(rate_window_start_ns);
        if window_ns >= 1_000_000_000 {
            trace_mark_input(
                input_source::PS2_MOUSE,
                rate_window_input,
                rate_window_input / 3,
                drop_counter as u64,
            );
            stem::debug!(
                "ps2_mouse input rate: bytes_per_sec={} total={} irq_wakes={} poll_timeouts={} dropped={}.",
                rate_window_input,
                input_count,
                irq_wake_count,
                timeout_count,
                drop_counter
            );
            rate_window_start_ns = now_ns;
            rate_window_input = 0;
        }

        if (irq_wake_count + timeout_count) % 256 == 0 {
            trace!(
                "PS/2 mouse input loop: irq_wakes={} poll_timeouts={} last_drain_bytes={}",
                irq_wake_count, timeout_count, drained
            );
        }
    }
    polling_loop(bristle_pid)
}

fn should_log_input(count: u64) -> bool {
    count <= INPUT_TRACE_INITIAL || count % INPUT_TRACE_INTERVAL == 0
}

/// Fallback polling loop – used only when IRQ subscription or wait fails.
fn polling_loop(bristle_pid: u32) -> ! {
    debug!("Using PS/2 mouse fallback polling loop: interval={}ms", POLLING_INTERVAL_MS);

    let mut packet = [0u8; 3];
    let mut idx = 0usize;
    let mut mouse_state = MouseState::new();
    let mut motion = MotionCoalescer::default();
    let mut drop_counter = 0u32;

    loop {
        let status = ioport_read(PS2_STATUS, 1);

        if status & STATUS_OUTPUT_FULL != 0 {
            if status & STATUS_AUX_DATA != 0 {
                drain_mouse_data(
                    bristle_pid,
                    &mut mouse_state,
                    &mut motion,
                    &mut packet,
                    &mut idx,
                    &mut drop_counter,
                );
                flush_motion_if_due(bristle_pid, &mut motion, &mut drop_counter);
            } else {
                // Leave keyboard bytes queued for ps2_kbd.
                stem::sleep_ms(POLLING_INTERVAL_MS);
            }
        } else {
            stem::sleep_ms(POLLING_INTERVAL_MS);
        }
        // No unconditional sleep here - the per-branch sleeps above are sufficient.
    }
}
