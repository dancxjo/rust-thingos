//! VFS node wrapper for IPC ports.
//!
//! This allows IPC ports to be treated as VFS nodes, enabling them to be
//! passed across ports using the standard handle-passing mechanism.

use alloc::sync::Arc;
use core::sync::atomic::{AtomicU64, Ordering};

use abi::errors::SysResult;

use super::{VfsNode, VfsStat};
use crate::ipc::{IpcHandleMode, Port};

static PORT_NODE_READ_TRACE_COUNT: AtomicU64 = AtomicU64::new(0);

/// A VFS node that wraps an IPC port.
pub struct PortNode {
    port: Arc<Port>,
    mode: IpcHandleMode,
    closed: core::sync::atomic::AtomicBool,
}

impl PortNode {
    pub fn new(port: Arc<Port>, mode: IpcHandleMode) -> Self {
        match mode {
            IpcHandleMode::Read => port.open_reader(),
            IpcHandleMode::Write => port.open_writer(),
        }
        Self { port, mode, closed: core::sync::atomic::AtomicBool::new(false) }
    }

    pub fn port(&self) -> &Arc<Port> {
        &self.port
    }
}

impl VfsNode for PortNode {
    fn read(&self, _offset: u64, buf: &mut [u8]) -> SysResult<usize> {
        if self.mode != IpcHandleMode::Read {
            return Err(abi::errors::Errno::EBADF);
        }
        let trace_no = PORT_NODE_READ_TRACE_COUNT.fetch_add(1, Ordering::Relaxed) + 1;
        let should_trace = trace_no <= 32 || trace_no % 128 == 0;
        let start_ns = if should_trace { crate::time::monotonic_now_ns() } else { 0 };
        let queued_before = if should_trace { self.port.len() } else { 0 };
        let writers_before = should_trace && self.port.has_writers();
        let n = self.port.try_recv(buf);
        if should_trace {
            crate::ktrace!(
                "port node read trace={} port={:p} requested={} queued_before={} writers={} bytes={} queued_after={} elapsed_ns={}",
                trace_no,
                Arc::as_ptr(&self.port),
                buf.len(),
                queued_before,
                writers_before,
                n,
                self.port.len(),
                crate::time::monotonic_now_ns().saturating_sub(start_ns)
            );
        }
        Ok(n)
    }

    fn write(&self, _offset: u64, buf: &[u8]) -> SysResult<usize> {
        if self.mode != IpcHandleMode::Write {
            return Err(abi::errors::Errno::EBADF);
        }
        Ok(self.port.send(buf))
    }

    fn stat(&self) -> SysResult<VfsStat> {
        let (r, w) = if self.mode == IpcHandleMode::Read { (0o400, 0) } else { (0, 0o200) };
        Ok(VfsStat {
            mode: VfsStat::S_IFIFO | r | w,
            size: self.port.len() as u64,
            ino: 0,
            ..Default::default()
        })
    }

    fn poll(&self) -> u16 {
        use abi::syscall::poll_flags::{POLLERR, POLLHUP, POLLIN, POLLOUT};
        let mut revents = 0;
        match self.mode {
            IpcHandleMode::Read => {
                let empty = self.port.is_empty();
                let has_writers = self.port.has_writers();
                if !empty || !has_writers {
                    revents |= POLLIN;
                }
                if !has_writers {
                    revents |= POLLHUP;
                }
            }
            IpcHandleMode::Write => {
                if !self.port.has_readers() {
                    revents |= POLLHUP | POLLERR;
                } else if !self.port.is_full() {
                    revents |= POLLOUT;
                }
            }
        }
        revents
    }

    fn close(&self) {
        if self.closed.swap(true, core::sync::atomic::Ordering::SeqCst) {
            return;
        }
        match self.mode {
            IpcHandleMode::Read => {
                self.port.close_reader();
            }
            IpcHandleMode::Write => {
                self.port.close_writer();
            }
        }
    }

    fn add_waiter(&self, tid: u64) {
        match self.mode {
            IpcHandleMode::Read => self.port.add_waiter_read(tid),
            IpcHandleMode::Write => self.port.add_waiter_write(tid),
        }
    }

    fn remove_waiter(&self, tid: u64) {
        match self.mode {
            IpcHandleMode::Read => self.port.remove_waiter_read(tid),
            IpcHandleMode::Write => self.port.remove_waiter_write(tid),
        }
    }

    fn as_port(&self) -> Option<Arc<Port>> {
        Some(self.port.clone())
    }

    fn sock_sendmsg(
        &self,
        data: &[u8],
        fds: alloc::vec::Vec<Arc<dyn VfsNode>>,
    ) -> abi::errors::SysResult<()> {
        if self.mode != IpcHandleMode::Write {
            return Err(abi::errors::Errno::EBADF);
        }
        let caps_len = fds.len();
        crate::ktrace!(
            "PORT_NODE: sock_sendmsg caps_len={} port={:p}",
            caps_len,
            Arc::as_ptr(&self.port)
        );
        self.port.send_msg(data.to_vec(), fds).map_err(|e| match e {
            crate::ipc::msgqueue::MqSendError::Full { capacity } => {
                crate::ktrace!(
                    "PORT: sock_sendmsg rejected: message queue full (capacity={})",
                    capacity
                );
                abi::errors::Errno::EAGAIN
            }
            crate::ipc::msgqueue::MqSendError::Closed => abi::errors::Errno::EPIPE,
        })
    }

    fn sock_recvmsg(
        &self,
    ) -> abi::errors::SysResult<Option<(alloc::vec::Vec<u8>, alloc::vec::Vec<Arc<dyn VfsNode>>)>>
    {
        if self.mode != IpcHandleMode::Read {
            return Err(abi::errors::Errno::EBADF);
        }
        match self.port.try_recv_msg() {
            Some(msg) => {
                crate::ktrace!(
                    "PORT_NODE: sock_recvmsg caps_len={} port={:p}",
                    msg.caps.len(),
                    Arc::as_ptr(&self.port)
                );
                Ok(Some((msg.data, msg.caps)))
            }
            None => Ok(None),
        }
    }
}

impl Drop for PortNode {
    fn drop(&mut self) {
        self.close();
    }
}

#[cfg(test)]
mod tests {
    use abi::syscall::poll_flags;

    use super::*;

    fn make_port(capacity: usize) -> (Arc<PortNode>, Arc<PortNode>) {
        let port = Arc::new(Port::new(capacity));
        let read_node = Arc::new(PortNode::new(Arc::clone(&port), IpcHandleMode::Read));
        let write_node = Arc::new(PortNode::new(Arc::clone(&port), IpcHandleMode::Write));
        (read_node, write_node)
    }

    // ── Read-handle poll semantics ─────────────────────────────────────────

    #[test]
    fn read_handle_not_ready_when_empty_with_writer() {
        let (r, _w) = make_port(64);
        // Empty queue, writer still alive → not readable.
        assert_eq!(r.poll() & poll_flags::POLLIN, 0);
    }

    #[test]
    fn read_handle_ready_after_send() {
        let (r, w) = make_port(64);
        w.write(0, b"hi").expect("write");
        assert_ne!(r.poll() & poll_flags::POLLIN, 0, "POLLIN set after send");
    }

    #[test]
    fn read_handle_reports_pollhup_when_writer_closed() {
        let (r, w) = make_port(64);
        // Closing the write handle signals hangup on the read handle.
        w.close();
        assert_ne!(r.poll() & poll_flags::POLLIN, 0, "POLLIN set on EOF");
        assert_ne!(r.poll() & poll_flags::POLLHUP, 0, "POLLHUP set when writer closed");
    }

    #[test]
    fn read_handle_reports_both_pollin_and_pollhup_with_data_and_closed_writer() {
        let (r, w) = make_port(64);
        w.write(0, b"x").expect("write");
        w.close();
        let flags = r.poll();
        assert_ne!(flags & poll_flags::POLLIN, 0, "POLLIN set when data present");
        assert_ne!(flags & poll_flags::POLLHUP, 0, "POLLHUP set when writer gone");
    }

    // ── Write-handle poll semantics ────────────────────────────────────────

    #[test]
    fn write_handle_ready_when_queue_has_space() {
        let (_r, w) = make_port(64);
        assert_ne!(w.poll() & poll_flags::POLLOUT, 0, "POLLOUT when space available");
    }

    #[test]
    fn write_handle_reports_pollhup_when_reader_closed() {
        let (r, w) = make_port(64);
        // Closing the read handle signals broken-pipe on the write handle.
        r.close();
        let flags = w.poll();
        assert_ne!(flags & poll_flags::POLLHUP, 0, "POLLHUP when reader closed");
        assert_ne!(flags & poll_flags::POLLERR, 0, "POLLERR when reader closed");
    }

    #[test]
    fn write_handle_not_pollout_when_queue_full() {
        // Use a small capacity so we can fill it.
        let (_r, w) = make_port(16);
        // Fill the queue completely.
        w.write(0, &[0u8; 16]).expect("write");
        assert_eq!(w.poll() & poll_flags::POLLOUT, 0, "POLLOUT clear when queue full");
    }
}
