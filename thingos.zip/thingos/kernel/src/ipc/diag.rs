//! IPC diagnostics — global counters for ports, pipes, and VFS RPC.
//!
//! All counters are `AtomicU64` incremented at the hot path (no locking).
//! Expose them via `/proc/ipc/ports` and `/proc/ipc/pipes`.
//!
//! # Usage
//!
//! Increment from the relevant hot path:
//! ```ignore
//! crate::ipc::diag::PORT_SENDS.fetch_add(1, Ordering::Relaxed);
//! ```
//!
//! Read for display:
//! ```ignore
//! let s = crate::ipc::diag::ports_text();
//! ```

use core::sync::atomic::{AtomicU64, Ordering};

// ── Port counters ─────────────────────────────────────────────────────────────

/// Total `sys_port_send` calls that wrote ≥1 byte.
pub static PORT_SENDS: AtomicU64 = AtomicU64::new(0);
/// Total `sys_port_recv` calls that read ≥1 byte.
pub static PORT_RECVS: AtomicU64 = AtomicU64::new(0);
/// Cumulative bytes written via port send.
pub static PORT_BYTES_SENT: AtomicU64 = AtomicU64::new(0);
/// Cumulative bytes read via port receive.
pub static PORT_BYTES_RECV: AtomicU64 = AtomicU64::new(0);
/// Total capability handles enqueued via `sendmsg`.
pub static PORT_HANDLES_SENT: AtomicU64 = AtomicU64::new(0);
/// Total capability handles dequeued via `recvmsg`.
pub static PORT_HANDLES_RECV: AtomicU64 = AtomicU64::new(0);
/// Times a send returned `EAGAIN` because the ring was full.
pub static PORT_FULL_EVENTS: AtomicU64 = AtomicU64::new(0);
/// Times a peer closure was observed (writer or reader).
pub static PORT_PEER_DEATHS: AtomicU64 = AtomicU64::new(0);

// ── Pipe counters ─────────────────────────────────────────────────────────────

/// Total pipe write calls that wrote ≥1 byte.
pub static PIPE_WRITES: AtomicU64 = AtomicU64::new(0);
/// Total pipe read calls that read ≥1 byte.
pub static PIPE_READS: AtomicU64 = AtomicU64::new(0);
/// Cumulative bytes written to pipes.
pub static PIPE_BYTES_WRITTEN: AtomicU64 = AtomicU64::new(0);
/// Cumulative bytes read from pipes.
pub static PIPE_BYTES_READ: AtomicU64 = AtomicU64::new(0);
/// Times a pipe write returned `EPIPE` (broken pipe).
pub static PIPE_BROKEN_PIPE: AtomicU64 = AtomicU64::new(0);

// ── VFS RPC counters ──────────────────────────────────────────────────────────

/// Total VFS RPC requests dispatched to providers.
pub static VFS_RPC_REQUESTS: AtomicU64 = AtomicU64::new(0);
/// Total VFS RPC requests that completed with an error.
pub static VFS_RPC_ERRORS: AtomicU64 = AtomicU64::new(0);
/// Total VFS RPC requests that failed because the provider was dead.
pub static VFS_RPC_DEAD_PROVIDER: AtomicU64 = AtomicU64::new(0);

// ── Text renderers ────────────────────────────────────────────────────────────

/// Record a dead-provider error: increments both `VFS_RPC_ERRORS` and
/// `VFS_RPC_DEAD_PROVIDER`.  Call this whenever a VFS RPC send fails or the
/// response port returns `EPIPE` (provider exited mid-call).
#[inline]
pub fn record_dead_provider_error() {
    VFS_RPC_ERRORS.fetch_add(1, Ordering::Relaxed);
    VFS_RPC_DEAD_PROVIDER.fetch_add(1, Ordering::Relaxed);
}

/// Render port counters as a human-readable text block (for `/proc/ipc/ports`).
pub fn ports_text() -> alloc::string::String {
    alloc::format!(
        "sends:         {}\n\
         recvs:         {}\n\
         bytes_sent:    {}\n\
         bytes_recv:    {}\n\
         handles_sent:  {}\n\
         handles_recv:  {}\n\
         full_events:   {}\n\
         peer_deaths:   {}\n",
        PORT_SENDS.load(Ordering::Relaxed),
        PORT_RECVS.load(Ordering::Relaxed),
        PORT_BYTES_SENT.load(Ordering::Relaxed),
        PORT_BYTES_RECV.load(Ordering::Relaxed),
        PORT_HANDLES_SENT.load(Ordering::Relaxed),
        PORT_HANDLES_RECV.load(Ordering::Relaxed),
        PORT_FULL_EVENTS.load(Ordering::Relaxed),
        PORT_PEER_DEATHS.load(Ordering::Relaxed),
    )
}

/// Render pipe counters as a human-readable text block (for `/proc/ipc/pipes`).
pub fn pipes_text() -> alloc::string::String {
    alloc::format!(
        "writes:        {}\n\
         reads:         {}\n\
         bytes_written: {}\n\
         bytes_read:    {}\n\
         broken_pipe:   {}\n",
        PIPE_WRITES.load(Ordering::Relaxed),
        PIPE_READS.load(Ordering::Relaxed),
        PIPE_BYTES_WRITTEN.load(Ordering::Relaxed),
        PIPE_BYTES_READ.load(Ordering::Relaxed),
        PIPE_BROKEN_PIPE.load(Ordering::Relaxed),
    )
}

/// Render VFS RPC counters as a human-readable text block (for `/proc/ipc/vfs_rpc`).
pub fn vfs_rpc_text() -> alloc::string::String {
    alloc::format!(
        "requests:      {}\n\
         errors:        {}\n\
         dead_provider: {}\n",
        VFS_RPC_REQUESTS.load(Ordering::Relaxed),
        VFS_RPC_ERRORS.load(Ordering::Relaxed),
        VFS_RPC_DEAD_PROVIDER.load(Ordering::Relaxed),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ports_text_contains_expected_keys() {
        let t = ports_text();
        assert!(t.contains("sends:"));
        assert!(t.contains("bytes_sent:"));
        assert!(t.contains("handles_sent:"));
        assert!(t.contains("peer_deaths:"));
    }

    #[test]
    fn pipes_text_contains_expected_keys() {
        let t = pipes_text();
        assert!(t.contains("writes:"));
        assert!(t.contains("broken_pipe:"));
    }

    #[test]
    fn vfs_rpc_text_contains_expected_keys() {
        let t = vfs_rpc_text();
        assert!(t.contains("requests:"));
        assert!(t.contains("dead_provider:"));
    }
}
